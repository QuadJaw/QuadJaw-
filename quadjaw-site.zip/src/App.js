
import './App.css';

function App() {
  return (
    <div style={{ backgroundColor: '#111', color: '#fff', minHeight: '100vh', padding: '2rem', textAlign: 'center' }}>
      <h1 style={{ fontSize: '3rem' }}>QuadJaw™</h1>
      <p style={{ fontSize: '1.5rem' }}>Four Wrenches. Forty Replaced. One Revolution.</p>
      <img src="/quadjaw-hero.jpg" alt="QuadJaw Hero" style={{ maxWidth: '100%', margin: '2rem 0' }} />
      <h2>Replaces 40 Tools with 4</h2>
      <p>Universal clamping. M4 Tool Steel. Made in the USA.</p>
    </div>
  );
}

export default App;
